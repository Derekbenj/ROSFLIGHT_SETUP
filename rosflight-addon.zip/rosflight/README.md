# ROSFlight add-on for generic-bulletproof-v4

This add-on is meant to be run **inside** the Distrobox home created by `generic-bulletproof-v4`, after the generic scripts have already completed.

It creates/uses this layout:

```text
~/rosflight/
  scripts/
  workspace/
    src/
```

It intentionally does **not** install Rust/Cargo or `uv`, because `generic-bulletproof-v4` already handles those for you.

## Run

From inside the Distrobox:

```zsh
cd ~
unzip rosflight-addon-for-generic-v2.zip
cd ~/rosflight
./scripts/run_all.zsh
```

Or run step-by-step:

```zsh
cd ~/rosflight
./scripts/00_install_ros2_jazzy_tools.zsh
./scripts/01_import_rosflight_repos.zsh
./scripts/02_rosdep_install.zsh
./scripts/03_build_workspace.zsh
source ./scripts/source_rosflight_env.zsh
```

After a successful build, new shells should automatically source the ROSFlight environment via `~/.zshrc.local` if your dotfiles load that file. You can always source it manually:

```zsh
source ~/rosflight/scripts/source_rosflight_env.zsh
```

## Notes

- Assumes Ubuntu 24.04 / Noble inside the Distrobox, matching the generic script default.
- Uses ROS 2 Jazzy.
- Imports these repositories into `~/rosflight/workspace/src`:
  - `rosflight/rosflight_ros_pkgs`
  - `rosflight/roscopter`
  - `rosflight/rosplane`
