#!/usr/bin/env zsh

rosflight_require_container() {
  if [[ ! -f /run/.containerenv && ! -f /.dockerenv ]]; then
    echo "[error] This must be run inside the Distrobox container."
    exit 1
  fi
}

rosflight_project_root() {
  local script_dir="${0:A:h}"
  echo "${script_dir:h}"
}

rosflight_source_jazzy() {
  if [[ ! -f /opt/ros/jazzy/setup.zsh ]]; then
    echo "[error] /opt/ros/jazzy/setup.zsh not found."
    echo "[hint] Run: ~/rosflight/scripts/00_install_ros2_jazzy_tools.zsh"
    exit 1
  fi

  # ROS setup scripts sometimes assume unset-friendly shells.
  unsetopt nounset 2>/dev/null || true
  unsetopt no_unset 2>/dev/null || true

  source /opt/ros/jazzy/setup.zsh
  export ROS_DISTRO=jazzy
  export ROS_PYTHON_VERSION=3
}
