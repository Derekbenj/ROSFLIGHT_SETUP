#!/usr/bin/env zsh
set -euo pipefail

SCRIPT_DIR="${0:A:h}"
source "$SCRIPT_DIR/_common.zsh"
rosflight_require_container

PROJECT_ROOT="${SCRIPT_DIR:h}"
WORKSPACE="$PROJECT_ROOT/workspace"
mkdir -p "$WORKSPACE/src"

if [[ -r /etc/os-release ]]; then
  source /etc/os-release
fi

if [[ "${VERSION_CODENAME:-}" != "noble" ]]; then
  echo "[error] ROS 2 Jazzy packages are expected on Ubuntu 24.04 / noble."
  echo "[error] Detected VERSION_CODENAME=${VERSION_CODENAME:-unknown}"
  exit 1
fi

echo "[deps] Installing ROS 2 Jazzy repo and build tooling..."

sudo apt-get update
sudo apt-get install -y \
  curl \
  git \
  ca-certificates \
  gnupg \
  lsb-release \
  locales \
  software-properties-common

sudo add-apt-repository universe -y
sudo install -m 0755 -d /etc/apt/keyrings

if [[ ! -f /etc/apt/keyrings/ros-archive-keyring.gpg ]]; then
  sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key \
    -o /etc/apt/keyrings/ros-archive-keyring.gpg
fi

ARCH="$(dpkg --print-architecture)"
ROS_APT_LINE="deb [arch=$ARCH signed-by=/etc/apt/keyrings/ros-archive-keyring.gpg] http://packages.ros.org/ros2/ubuntu noble main"
echo "$ROS_APT_LINE" | sudo tee /etc/apt/sources.list.d/ros2.list >/dev/null

sudo apt-get update
sudo apt-get install -y \
  ros-jazzy-desktop \
  ros-dev-tools \
  python3-colcon-common-extensions \
  python3-vcstool \
  python3-rosdep \
  ros-jazzy-mavlink \
  gcc-arm-none-eabi \
  gdb-multiarch \
  openocd

sudo rosdep init 2>/dev/null || true
rosdep update || true

MARKER_BEGIN="# >>> rosflight jazzy env >>>"
MARKER_END="# <<< rosflight jazzy env <<<"
ZSHRC_LOCAL="$HOME/.zshrc.local"
TMP="$(mktemp)"

if [[ -f "$ZSHRC_LOCAL" ]]; then
  awk "/$MARKER_BEGIN/{flag=1;next}/$MARKER_END/{flag=0;next}!flag" "$ZSHRC_LOCAL" > "$TMP"
else
  touch "$TMP"
fi

cat >> "$TMP" <<EOF2
$MARKER_BEGIN
if [[ -f "\$HOME/rosflight/scripts/source_rosflight_env.zsh" ]]; then
  source "\$HOME/rosflight/scripts/source_rosflight_env.zsh"
fi
$MARKER_END
EOF2

mv "$TMP" "$ZSHRC_LOCAL"

echo "[deps] Done. Environment hook added to ~/.zshrc.local."
