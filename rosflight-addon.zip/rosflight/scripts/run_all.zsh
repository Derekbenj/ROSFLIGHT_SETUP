#!/usr/bin/env zsh
set -euo pipefail

SCRIPT_DIR="${0:A:h}"

"$SCRIPT_DIR/00_install_ros2_jazzy_tools.zsh"
"$SCRIPT_DIR/01_import_rosflight_repos.zsh"
"$SCRIPT_DIR/02_rosdep_install.zsh"
"$SCRIPT_DIR/03_build_workspace.zsh"

echo ""
echo "[done] ROSFlight setup complete."
echo "[done] Run now: source ~/rosflight/scripts/source_rosflight_env.zsh"
echo "[done] Or open a new zsh shell if your dotfiles source ~/.zshrc.local."
