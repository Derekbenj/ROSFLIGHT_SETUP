#!/usr/bin/env zsh
set -eo pipefail

SCRIPT_DIR="${0:A:h}"
source "$SCRIPT_DIR/_common.zsh"
rosflight_require_container
rosflight_source_jazzy

PROJECT_ROOT="${SCRIPT_DIR:h}"
WORKSPACE="$PROJECT_ROOT/workspace"

if [[ ! -d "$WORKSPACE/src" ]]; then
  echo "[error] Missing $WORKSPACE/src. Run import first."
  exit 1
fi

cd "$WORKSPACE"

echo "[build] Building ROSFlight workspace..."
colcon build --symlink-install --event-handlers console_direct+

echo "[build] Success."
echo "[build] Run: source ~/rosflight/scripts/source_rosflight_env.zsh"
