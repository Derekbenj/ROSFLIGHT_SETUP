#!/usr/bin/env zsh
emulate -L zsh

unsetopt nounset 2>/dev/null || true
unsetopt no_unset 2>/dev/null || true

SCRIPT_DIR="${${(%):-%x}:A:h}"
PROJECT_ROOT="${SCRIPT_DIR:h}"
WORKSPACE="$PROJECT_ROOT/workspace"

if [[ -f /opt/ros/jazzy/setup.zsh ]]; then
  source /opt/ros/jazzy/setup.zsh
fi

if [[ -f "$WORKSPACE/install/setup.zsh" ]]; then
  source "$WORKSPACE/install/setup.zsh"
fi

export ROS_DISTRO=jazzy
export ROS_PYTHON_VERSION=3
export ROSFLIGHT_HOME="$PROJECT_ROOT"
export ROSFLIGHT_WS="$WORKSPACE"
