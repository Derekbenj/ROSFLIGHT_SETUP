#!/usr/bin/env zsh
set -euo pipefail

SCRIPT_DIR="${0:A:h}"
source "$SCRIPT_DIR/_common.zsh"
rosflight_require_container

PROJECT_ROOT="${SCRIPT_DIR:h}"
WORKSPACE="$PROJECT_ROOT/workspace"
REPOS_FILE="$PROJECT_ROOT/rosflight.repos"

mkdir -p "$WORKSPACE/src"
cd "$WORKSPACE"

if ! command -v vcs >/dev/null 2>&1; then
  echo "[error] vcs not found. Run: ~/rosflight/scripts/00_install_ros2_jazzy_tools.zsh"
  exit 1
fi

cp "$REPOS_FILE" "$WORKSPACE/rosflight.repos"

echo "[import] Importing ROSFlight repositories into $WORKSPACE/src"
# vcstool is idempotent for existing matching repositories in normal use, but if
# a repo already exists with local changes, it will not overwrite them.
vcs import src < rosflight.repos

for repo in src/rosflight_ros_pkgs src/roscopter src/rosplane; do
  if [[ -d "$repo/.git" ]]; then
    echo "[import] Updating submodules for $repo"
    git -C "$repo" submodule update --init --recursive || true
  fi
done

echo "[import] Done."
