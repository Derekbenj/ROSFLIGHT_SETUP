#!/usr/bin/env zsh
set -euo pipefail

SCRIPT_DIR="${0:A:h}"
PROJECT_ROOT="${SCRIPT_DIR:h}"
PROJECT_NAME="${PROJECT_NAME:-${PROJECT_ROOT:t}}"

DOTFILES_REPO="${DOTFILES_REPO:-git@github.com:Derekbenj/dotfiles.git}"
DOTFILES_BRANCH="${DOTFILES_BRANCH:-main}"
DOTFILES_CONTAINER_NAME="${DOTFILES_CONTAINER_NAME:-$PROJECT_NAME}"

echo "[bootstrap] Container: $PROJECT_NAME"
echo "[bootstrap] Dotfiles repo: $DOTFILES_REPO"
echo "[bootstrap] Dotfiles branch: $DOTFILES_BRANCH"

# Suppress zsh-newuser-install if zsh starts before stow finishes.
distrobox enter "$PROJECT_NAME" -- bash -lc '
  if [[ ! -e "$HOME/.zshrc" ]]; then
    echo "# Temporary .zshrc created by bootstrap; replaced by stow." > "$HOME/.zshrc"
  fi
'

distrobox enter "$PROJECT_NAME" -- bash -lc '
  set -euo pipefail
  echo "[bootstrap] Installing git/ssh/certs first..."
  sudo apt-get update
  sudo apt-get install -y git openssh-client ca-certificates curl
'

distrobox enter "$PROJECT_NAME" -- bash -lc "
  set -euo pipefail

  if [[ -d \"\$HOME/dotfiles/.git\" ]]; then
    echo \"[bootstrap] Updating existing ~/dotfiles...\"
    cd \"\$HOME/dotfiles\"
    git fetch origin
    git checkout \"$DOTFILES_BRANCH\"
    git pull --ff-only origin \"$DOTFILES_BRANCH\"
  else
    echo \"[bootstrap] Cloning dotfiles into container HOME: ~/dotfiles\"
    rm -rf \"\$HOME/dotfiles\"
    git clone --branch \"$DOTFILES_BRANCH\" \"$DOTFILES_REPO\" \"\$HOME/dotfiles\"
  fi

  cd \"\$HOME/dotfiles\"
  ./scripts/install_favorites.sh

  cat > \"\$HOME/.zshrc.local\" <<EOF
export DOTFILES_CONTAINER_PROMPT=1
export DOTFILES_CONTAINER_NAME=\"$DOTFILES_CONTAINER_NAME\"
EOF

  ./scripts/install.sh
"

echo "[bootstrap] Done. Enter with: ./scripts/02_enter_distrobox.zsh"
