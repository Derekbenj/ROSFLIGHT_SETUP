#!/usr/bin/env zsh
set -euo pipefail
SCRIPT_DIR="${0:A:h}"
PROJECT_ROOT="${SCRIPT_DIR:h}"
PROJECT_NAME="${PROJECT_NAME:-${PROJECT_ROOT:t}}"
echo "[destroy] Removing distrobox: $PROJECT_NAME"
distrobox rm --force "$PROJECT_NAME" || true
docker rm -f "$PROJECT_NAME" 2>/dev/null || true
podman rm -f "$PROJECT_NAME" 2>/dev/null || true
