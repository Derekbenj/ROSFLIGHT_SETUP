#!/usr/bin/env zsh
set -euo pipefail

SCRIPT_DIR="${0:A:h}"
PROJECT_ROOT="${SCRIPT_DIR:h}"
PROJECT_NAME="${PROJECT_NAME:-${PROJECT_ROOT:t}}"
DISTROBOX_HOME="${DISTROBOX_HOME:-$PROJECT_ROOT/.distrobox-home/$PROJECT_NAME}"
IMAGE="${DISTROBOX_IMAGE:-ubuntu:24.04}"

mkdir -p "$DISTROBOX_HOME"

echo "[create] Project: $PROJECT_NAME"
echo "[create] Image:   $IMAGE"
echo "[create] Home:    $DISTROBOX_HOME"

distrobox create \
  --name "$PROJECT_NAME" \
  --image "$IMAGE" \
  --home "$DISTROBOX_HOME" \
  --additional-flags "--privileged --security-opt seccomp=unconfined --ipc=host --pid=host --device /dev:/dev" \
  --volume "$PROJECT_ROOT:$PROJECT_ROOT" \
  --yes
