#!/usr/bin/env zsh
set -euo pipefail
SCRIPT_DIR="${0:A:h}"
PROJECT_ROOT="${SCRIPT_DIR:h}"
PROJECT_NAME="${PROJECT_NAME:-${PROJECT_ROOT:t}}"

if distrobox enter "$PROJECT_NAME" -- test -x /usr/bin/zsh >/dev/null 2>&1; then
  distrobox enter "$PROJECT_NAME" -- /usr/bin/zsh -l
else
  distrobox enter "$PROJECT_NAME"
fi
