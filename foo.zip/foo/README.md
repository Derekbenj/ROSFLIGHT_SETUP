# generic Distrobox wrapper

Run from the host:

```bash
./scripts/00_destroy_distrobox.zsh
./scripts/01_create_distrobox.zsh
./scripts/03_bootstrap_dotfiles.zsh
./scripts/02_enter_distrobox.zsh
```
